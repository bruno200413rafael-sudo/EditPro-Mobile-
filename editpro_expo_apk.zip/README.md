# EditPro Mobile (Expo) — Prototype for Android (Light mode, saves to gallery)

This project is a React Native (Expo) prototype configured to run on Android devices.
It includes basic image picking, simple brightness adjustment via `ImageManipulator`, and saving the edited image to the device gallery.

## What I created for you
- A working Expo project scaffold (`App.js`) with light-mode UI and simple editing features.
- Permissions and configuration in `app.json` for Android.
- Instructions to build an APK using EAS (Expo Application Services).

## Important: I cannot build the APK inside this environment.
I created the full project files and packaged them for you. To generate the actual `.apk` file you will need to run the build on your machine or use Expo's EAS cloud build service. Steps below.

---
## Quick start (simplified)
1. Install Node.js (>=18) and npm.
2. Install Expo CLI and EAS CLI globally:
   ```bash
   npm install -g expo-cli eas-cli
   ```
3. In the project folder, install dependencies:
   ```bash
   npm install
   ```
4. (Optional) Test locally on your phone using Expo Go:
   ```bash
   expo start
   ```
   Scan the QR code with the Expo Go app (Android) to preview the app — note: some native saving features require a standalone build.

## Build a standalone Android APK using EAS (recommended)
1. Log in or create an Expo account:
   ```bash
   eas login
   ```
2. Configure EAS for the project (run once):
   ```bash
   eas build:configure
   ```
3. Start an Android build (APK):
   ```bash
   eas build -p android --profile production
   ```
   or to produce an Android App Bundle (AAB):
   ```bash
   eas build -p android --profile preview
   ```
4. After the build completes, you will get a URL to download the `.apk` or `.aab`. Download it to your phone and install (enable install from unknown sources).

## If you prefer to build locally (more advanced)
- You need Android Studio and Android SDK configured, then run:
  ```bash
  expo prebuild
  expo run:android
  ```
  This installs to a connected Android device or emulator.

## How to install the APK on your phone
- Download the produced `app-release.apk` to your phone.
- Open the file manager, tap the APK, and follow prompts to install (may require enabling "Install unknown apps").

## Notes about saving to gallery and permissions
- The app requests permission to access media library and camera. On modern Android versions you may need to grant permissions manually in Settings.
- Some features (saving to gallery) work only on the standalone build (not in Expo Go).

---
If you want, I can now package this project into a ZIP for you to download and run the build commands on a computer (or I can guide you step-by-step to build it on your machine).