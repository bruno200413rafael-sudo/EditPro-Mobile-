import React, { useState } from 'react';
import { View, Text, Button, Image, Slider, Platform, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';
import { StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';

export default function App() {
  const [image, setImage] = useState(null);
  const [brightness, setBrightness] = useState(0);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permissão necessária', 'Permissão para acessar a galeria é necessária.');
      return;
    }
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const applyEdit = async () => {
    if (!image) return;
    // Simple mock: use ImageManipulator to change brightness by an overlay (we'll use contrast-ish approach)
    const actions = [{ resize: { width: 1024 } }];
    // ImageManipulator doesn't have direct brightness; simulate with contrast/rotate/etc if needed.
    const edited = await ImageManipulator.manipulateAsync(image, actions, { compress: 0.9, format: ImageManipulator.SaveFormat.JPEG });
    setImage(edited.uri);
    Alert.alert('Edição aplicada', 'Edição simples aplicada (redimensionamento).');
  };

  const saveToGallery = async () => {
    if (!image) return;
    const { status } = await MediaLibrary.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permissão necessária', 'Permissão para salvar na galeria é necessária.');
      return;
    }
    const asset = await MediaLibrary.createAssetAsync(image);
    await MediaLibrary.createAlbumAsync('EditPro', asset, false).catch(() => {});
    Alert.alert('Salvo', 'Imagem salva na galeria (álbum EditPro).');
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>EditPro (modo claro)</Text>
      <View style={styles.preview}>
        {image ? <Image source={{ uri: image }} style={styles.image} resizeMode="contain" /> : <Text style={styles.placeholder}>Nenhuma imagem selecionada</Text>}
      </View>

      <View style={styles.controls}>
        <TouchableOpacity style={styles.button} onPress={pickImage}><Text style={styles.buttonText}>Escolher imagem</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={applyEdit}><Text style={styles.buttonText}>Aplicar edição</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={saveToGallery}><Text style={styles.buttonText}>Salvar na galeria</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff', alignItems: 'center' },
  title: { fontSize: 20, fontWeight: 'bold', marginTop: 20 },
  preview: { width: '95%', height: 350, backgroundColor: '#f3f4f6', marginTop: 20, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  image: { width: '100%', height: '100%', borderRadius: 12 },
  placeholder: { color: '#9ca3af' },
  controls: { width: '95%', marginTop: 16 },
  button: { backgroundColor: '#4f46e5', padding: 12, borderRadius: 8, marginBottom: 10 },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: '600' },
});
